package com.xadmin.SpringBootCurd.repository;

import org.springframework.data.repository.CrudRepository;

import com.xadmin.SpringBootCurd.bean.Subject;

public interface SubjectRepository extends CrudRepository<Subject,String> {

	
}
